<?php

namespace App\Models;

use CodeIgniter\Model;

class BranchModel extends Model
{
    protected $table = 'branches';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'company_id',
        'branch_code',
        'branch_name'
    ];
}
